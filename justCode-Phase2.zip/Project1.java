public class Project1 {
  public static void main(String[] args) {
    // Instantiate Primes Class
    Primes p = new Primes();

    MainWindow mw = new MainWindow(Config.APPLICATIONNAME, p);
  }
}
